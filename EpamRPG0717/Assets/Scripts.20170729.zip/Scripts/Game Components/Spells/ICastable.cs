using UnityEngine;

public interface ICastable {

    void Cast(GameObject caster);

}
