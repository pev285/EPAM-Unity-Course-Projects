public class BowShotCommand : AbstractCommand {

    public override void Execute() {
    }
}