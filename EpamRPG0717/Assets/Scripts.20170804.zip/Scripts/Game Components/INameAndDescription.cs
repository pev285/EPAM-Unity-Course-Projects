
public interface INameAndDescription {

    string Name { get; }

    string Description { get; }

}
