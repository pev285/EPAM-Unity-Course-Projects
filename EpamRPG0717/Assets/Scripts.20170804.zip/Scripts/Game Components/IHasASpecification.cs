public interface IHasASpecification {

    IGameObjectSpecification Specification { get; }
}
