public class EquippedObjects {

    public InventorySlot HeadSlot { set; get; }
    public InventorySlot BodySlot { set; get; }
    public InventorySlot RightArmSlot { set; get; }
    public InventorySlot LeftArmSlot { set; get; }
    public InventorySlot RightHandSlot { set; get; }
    public InventorySlot LeftHandSlot { set; get; }
    public InventorySlot RightLegSlot { set; get; }
    public InventorySlot LeftLegSlot { set; get; }

}