public class AbstractInventoryItem {


}