using UnityEngine;

public class Inventory : MonoBehaviour {

    InventoryModel model;
    InventoryView view;
}
