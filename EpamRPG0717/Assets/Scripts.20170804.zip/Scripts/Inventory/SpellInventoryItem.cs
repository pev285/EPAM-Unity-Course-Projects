public class SpellInventoryItem : AbstractInventoryItem  {

}