public class SinglePhisicalInventoryItem : AbstractPhisicalInventoryItem {

}