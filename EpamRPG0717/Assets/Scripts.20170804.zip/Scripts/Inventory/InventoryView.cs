using System.Collections.Generic;

public class InventoryView {



}