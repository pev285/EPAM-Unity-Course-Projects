using UnityEngine;

public abstract class AbstractDeathVisualizer : AbstractVisualizer{


}