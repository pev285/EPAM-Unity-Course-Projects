using UnityEngine;

public abstract class AbstractVisualizer : MonoBehaviour {

    public abstract void Visualize();
}
