
public class ThereIsNoCommand : AbstractCommand {

    public override void Execute() {
    }
}
