﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConsoleReader : MonoBehaviour {

    private ControllerEventSystem inputES;

    public void SetControllerEventSystem(ControllerEventSystem ces)
    {
        inputES = ces;
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.W))
        {
            inputES.InvokeStartForwardEvent();
        }
        if (Input.GetKeyUp(KeyCode.W))
        {
            inputES.InvokeStopForwardEvent();
        }
	}
}
