using System;
using UnityEngine;

public class GameManager : MonoBehaviour {


    // * Singleton * //

    public static GameManager Instance = null;

    void Awake() {
        //        print("GameManager is awake");
        //
        if (Instance == null) {
            Instance = this;
        } else {
            if (Instance != this) {
                Destroy(gameObject);
            }
        }

        DontDestroyOnLoad(gameObject);


        ////////////////////////////

        InitGame();
    }


    /////////////////////////////////////////////////////////////////////
    

    /////////////////////////////
    // GameObjects and Prefabs //
    /////////////////////////////

    Canvas inventoryCanvas;


    private GameObject player;

    private GameObject playerCamera;

    private GameObject targetingPoint;



    private CharacterModel characterModel;
    private SatelliteModel cameraModel;



    private GameObject stonePrefab;
    private GameObject arrowPrefab;
    private GameObject magnetPrefab;





    ////////////////////////////////////////////////////////////////////////////
    // ###################################################################### //
    ////////////////////////////////////////////////////////////////////////////

    public enum GameMode {
        GamePlay,
        Inventory
    }


    Dispatcher enemyKeyBinder;
    public Dispatcher EnemyKeyBinder {
        get {
            return enemyKeyBinder;
        }
    }

    Dispatcher gameModeKeyBinder;
    public Dispatcher GameModeKeyBinder {
        get {
            return gameModeKeyBinder;
        }
    }
    Dispatcher inventoryModeKeyBinder;
    Dispatcher InventoryModeKeyBinder {
        get {
            return inventoryModeKeyBinder;
        }
    }
//    KeyBinder currentKeyBinder;

    GameMode currentMode = GameMode.Inventory;
    public GameMode Mode {
        get {
            return currentMode;
        }
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    Starting initiation * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    void InitGame() {

        InitiateGameModeKeyBinderEvents();
        InitiateInventoryModeKeyBinderEvents();
        SubscribeOnKeyboardEvents();


        GoToMode(GameMode.GamePlay);

        InitiateSpells();

        ////////////////

        InitiateEnemyKeyBinder();
        InitiateEnemySpells();
        enemyController = enemyObject.GetComponent<CharacterController>();

    }


    private void InitiateSpells() {

        // PlayerModel??? //
        spells = player.GetComponent<EquippedSpells>();

        spells.AddSpell(new SimpleDistantSpell(new BowShotAction(arrowPrefab)));
        spells.AddSpell(new SimpleDistantSpell(new StoneThrowingAction(stonePrefab)));
        spells.AddSpell(new SimpleDistantSpell(new WindSpellAction()));
        spells.AddSpell(new SimpleDistantSpell(new MagnetoSpellAction(magnetPrefab)));


    }

    private void SubscribeOnKeyboardEvents() {
        inventoryModeKeyBinder.StartListening(DispatcherEventType.Pause, ChangeGameMode);
        gameModeKeyBinder.StartListening(DispatcherEventType.Pause, ChangeGameMode);

        // PlayerModel??? //

        gameModeKeyBinder.StartListening(DispatcherEventType.NextSpell, delegate  {
            spells.ShiftForward();
        });
        gameModeKeyBinder.StartListening(DispatcherEventType.PreviousSpell, delegate  {
            spells.ShiftBackward();
        });
        gameModeKeyBinder.StartListening(DispatcherEventType.PowerAttack, delegate  {
            spells.GetCurrentSpell().Cast(player, playerCamera, targetingPoint);
        });

    }

    private void InitiateGameModeKeyBinderEvents() {
        gameModeKeyBinder = gameObject.AddComponent<Dispatcher>();

        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate { return Input.GetKeyDown(KeyCode.P); }, DispatcherEventType.Pause));




//        ThrowStone,
//        FireBow,
//        LowRangeWeaponHit,


        /////
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  {
            return Input.GetKeyDown(KeyCode.LeftArrow); }, DispatcherEventType.PreviousSpell));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  {
            return Input.GetKeyDown(KeyCode.RightArrow); }, DispatcherEventType.NextSpell));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  {
            return Input.GetKeyDown(KeyCode.Mouse0); }, DispatcherEventType.PowerAttack));


        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return 
            Input.GetKeyDown(KeyCode.Space);
        }, DispatcherEventType.Jump));

        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  {
            return Input.GetKeyDown(KeyCode.RightControl);
        }, DispatcherEventType.StopCharRotation));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  {
            return Input.GetKeyUp(KeyCode.RightControl);
        }, DispatcherEventType.ResumeCharRotation));

        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  {
            return Input.GetKeyDown(KeyCode.Mouse2) || Input.GetKeyDown(KeyCode.Keypad5);
        }, DispatcherEventType.CameraDefaults));

        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse ScrollWheel") > 0; }, DispatcherEventType.CameraMoveNear));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse ScrollWheel") < 0; }, DispatcherEventType.CameraMoveAway));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse ScrollWheel") == 0; }, DispatcherEventType.CameraFixDistance));

        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse X") == 0; }, DispatcherEventType.StopHorizontalMouseMotion));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse X") > 0; }, DispatcherEventType.TurnRight));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse X") < 0; }, DispatcherEventType.TurnLeft));

        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse Y") == 0; }, DispatcherEventType.StopVerticalMouseMotion));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse Y") > 0; }, DispatcherEventType.TurnUp));
        gameModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate  { return Input.GetAxis("Mouse Y") < 0; }, DispatcherEventType.TurnDown));


    }

    private void InitiateInventoryModeKeyBinderEvents() {
        inventoryModeKeyBinder = gameObject.AddComponent<Dispatcher>();

        inventoryModeKeyBinder.AddKeyEvent(new DispatcherEvent(delegate { return Input.GetKeyDown(KeyCode.P); }, DispatcherEventType.Pause));
    }

    private void SelectKeyBinder() {
        if (IsPlaying) {
            gameModeKeyBinder.enabled = true;
            inventoryModeKeyBinder.enabled = false;
        } else {
            gameModeKeyBinder.enabled = false;
            inventoryModeKeyBinder.enabled = true;
        }
    }


    // *****************************************************************
    // *****************************************************************
    // *****************************************************************


    private void SetInventoryCanvasVisibility() {
        if (IsPlaying) {
            inventoryCanvas.enabled = false;
        } else {
            inventoryCanvas.enabled = true;
        }
    }


    public bool IsPlaying {
        get {
            return Mode == GameMode.GamePlay;
        }
    }



    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //
    // ############################################################################ //


    private void ReinitiateSettingsForCurrentMode()
    {
        SelectKeyBinder();
        SetInventoryCanvasVisibility();
    }

    public void GoToMode(GameMode mode)
    {
        currentMode = mode;
        ReinitiateSettingsForCurrentMode();
    }


    public void ChangeGameMode()
    {

        if (IsPlaying)
        {
            currentMode = GameMode.Inventory;
        }
        else
        {
            currentMode = GameMode.GamePlay;
        }
        ReinitiateSettingsForCurrentMode();
    }




    void HereIAm(GameObject gob)
    {
        TeamID tid= gob.GetComponent<TeamID>();

        if (tid != null)
        {
            // It is a character //

            InitiateSpells(gob, new AbstractSpell[] {
                    new SimpleDistantSpell(new StoneThrowingAction(stonePrefab)),
                    new SimpleDistantSpell(new BowShotAction(arrowPrefab)),
                    new SimpleDistantSpell(new WindSpellAction()),
                    new SimpleDistantSpell(new MagnetoSpellAction(magnetPrefab)),
                });

            if (tid.ThisTeam == TeamID.Teams.A)
            {
                // This is a player controlled character //
                player = gob;
                targetingPoint = player.transform.Find("TargetPoint").gameObject;

                // Init Controller //



            } else
            {
                // This is NPC //

                // Init Controller //



            }
        } else
        {
            // it is not a character //

            SatelliteModel smodel = gob.GetComponent<SatelliteModel>();

            if (smodel != null)
            {
                // it is the player camera //
                playerCamera = gob;
            }

        }
    }





    private void InitiateSpells(GameObject go, AbstractSpell[] spellsArray)
    {
        EquippedSpells spells = go.AddComponent<EquippedSpells>();

        foreach (AbstractSpell abSpell in spellsArray)
        {
            spells.AddSpell(abSpell);
        }


    }



        
    /// <summary>
    /// /////////////////////////////////////////////////////////////////////
    /// </summary>
    void Update()
    {
    }

}
