using UnityEngine;

public class zzzArrowScript : MonoBehaviour {

//    void OnTriggerEnter(Collider other) {
//        Health h = other.gameObject.GetComponent<Health>();
//        if (h != null) {
//            h.ChangeHealthBy(-15);
//        }
//        Destroy(gameObject);
//    }

    void Start() {
//        RayCast
    }

    void Update() {

    }


}