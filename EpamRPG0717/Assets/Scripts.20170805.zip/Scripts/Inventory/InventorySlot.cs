public class InventorySlot {

    private AbstractInventoryItem item;

    public AbstractInventoryItem Item {

        get {
            return item;
        }

        set {
            item = value;
        }
    }

}