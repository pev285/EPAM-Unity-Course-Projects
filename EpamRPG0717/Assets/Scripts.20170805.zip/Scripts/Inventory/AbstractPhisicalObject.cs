public class AbstractPhisicalObject : INameAndDescription  {


    public string Name {
        get {
            return null;
        }
    }

    public string Description {
        get {
            return null;
        }
    }


    /*
    private Image icon;
    private SpellAction? Spell?
*/

}