﻿using System;
using UnityEngine;

public class ControllerEventSystem
{

    public event Action startForwardEvent;
    public event Action startRightEvent;
    public event Action startLeftEvent;
    public event Action startBackEvent;

    public event Action stopForwardEvent;
    public event Action stopRightEvent;
    public event Action stopLeftEvent;
    public event Action stopBackEvent;

    public event Action<float> TurnHorizontalEvent;
    public event Action<float> TurnVerticalEvent;
    public event Action<float> ChangeCameraDistance;

    public event Action jumpEvent;

    public event Action prepareToFireEvent;
    public event Action<Quaternion> fireEvent;

    public event Action hitEvent;

    public event Action nextSpell;
    public event Action previousSpell;


    public void InvokeStartForwardEvent()
    {
        startForwardEvent();
    }
    public void InvokeStopForwardEvent()
    {
        stopForwardEvent();
    }

    public void InvokeTurnHorizontalEvent(float shift)
    {
        TurnHorizontalEvent(shift);
    }

}